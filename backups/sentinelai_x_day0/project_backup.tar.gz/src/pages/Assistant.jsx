import { API_BASE as API } from "../api";
import { useEffect, useState } from "react";
import {
  Bot,
  Send,
  ShieldAlert,
  Activity,
  BrainCircuit,
  Lock,
  Sparkles,
} from "lucide-react";
import PageLayout from "../components/PageLayout";
import "./Assistant.css";
const quickQuestions = [
  "Why was the latest threat blocked?",
  "What is the current risk score?",
  "What threat was detected?",
  "What do you recommend?",
];

function Assistant() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [latestThreat, setLatestThreat] = useState(null);
  useEffect(() => {
    loadLatestThreat();
  }, []);

  async function loadLatestThreat() {
    try {
      const response = await fetch(`${API}/api/threats`);
      const data = await response.json();

      if (Array.isArray(data) && data.length > 0) {
        setLatestThreat(data[data.length - 1]);
      }
    } catch (error) {
      console.error("Threat loading failed:", error);
    }
  }

  async function askAssistant(text = question) {
    const trimmed = text.trim();

    if (!trimmed || loading) return;

    setQuestion("");
    setMessages((prev) => [
      ...prev,
      { role: "user", text: trimmed },
    ]);

    setLoading(true);

    try {
      const token = sessionStorage.getItem("sentinelai_admin_token");

      if (!token) {
        throw new Error("ADMIN_LOGIN_REQUIRED");
      }

      const response = await fetch(`${API}/api/copilot/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ question: trimmed }),
      });

      const data = await response.json();

      if (response.status === 401 || response.status === 403) {
        throw new Error("ADMIN_SESSION_EXPIRED");
      }

      if (!response.ok) {
        throw new Error(
          typeof data.detail === "string"
            ? data.detail
            : "The SentinelAI Copilot could not complete the analysis."
        );
      }

      const ml = data.ml_analysis;
      const mlText = ml
        ? `\n\nML Analysis: ${ml.threat_type} | Confidence: ${ml.confidence}% | Anomaly score: ${ml.anomaly_score}`
        : "";

      const safetyText =
        "\n\nMode: Read-only | Administrator approval required for actions.";

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: `${data.answer || "No response generated."}${mlText}${safetyText}`,
        },
      ]);

      if (data.summary) {
        console.info("Copilot security context:", data.summary);
      }
    } catch (error) {
      let message =
        "Unable to connect to the SentinelAI Copilot. Check that the FastAPI backend is running.";

      if (error.message === "ADMIN_LOGIN_REQUIRED") {
        message = "Please sign in as an administrator before using SentinelAI Copilot.";
      } else if (error.message === "ADMIN_SESSION_EXPIRED") {
        message = "Your administrator session has expired. Please sign in again.";
      } else if (error.message && !["ADMIN_LOGIN_REQUIRED", "ADMIN_SESSION_EXPIRED"].includes(error.message)) {
        message = error.message;
      }

      setMessages((prev) => [
        ...prev,
        { role: "assistant", text: message },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageLayout>
      <div className="assistant-page">

        <div className="assistant-header">
          <div>
            <div className="assistant-title-row">
              <div className="assistant-icon">
                <Bot size={27} />
              </div>

              <div>
                <h1>AI Security Assistant</h1>
                <p>
                  Ask SecureX AI about threats, risk and security decisions
                </p>
              </div>
            </div>
          </div>

          <div className="assistant-online">
            <span className="online-dot"></span>
            AI ENGINE ONLINE
          </div>
        </div>

        <div className="assistant-grid">

          <section className="assistant-chat-card">

            <div className="card-heading">
              <div className="heading-icon">
                <BrainCircuit size={20} />
              </div>

              <div>
                <h2>SecureX AI Assistant</h2>
                <span>Security intelligence engine</span>
              </div>
            </div>

            <div className="chat-window">

              {messages.length === 0 ? (
                <div className="welcome-message">
                  <div className="welcome-icon">
                    <Sparkles size={24} />
                  </div>

                  <h3>Hello, I'm SecureX AI Security Assistant.</h3>

                  <p>
                    Ask me about threats, risk scores, blocked connections,
                    or recommended responses.
                  </p>
                </div>
              ) : (
                messages.map((message, index) => (
                  <div
                    key={index}
                    className={`chat-message ${message.role}`}
                  >
                    <div className="message-avatar">
                      {message.role === "assistant" ? (
                        <Bot size={16} />
                      ) : (
                        <Activity size={16} />
                      )}
                    </div>

                    <div className="message-bubble">
                      {message.text}
                    </div>
                  </div>
                ))
              )}

              {loading && (
                <div className="chat-message assistant">
                  <div className="message-avatar">
                    <Bot size={16} />
                  </div>

                  <div className="message-bubble typing">
                    Analyzing security events...
                    <span>•••</span>
                  </div>
                </div>
              )}

            </div>

            <div className="quick-section">
              <span className="quick-label">QUICK QUESTIONS</span>

              <div className="quick-buttons">
                {quickQuestions.map((item) => (
                  <button
                    key={item}
                    onClick={() => askAssistant(item)}
                    disabled={loading}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <form
              className="assistant-input"
              onSubmit={(e) => {
                e.preventDefault();
                askAssistant();
              }}
            >
              <input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask about your security events..."
              />

              <button type="submit" disabled={loading || !question.trim()}>
                <Send size={18} />
              </button>
            </form>

          </section>

          <aside className="threat-context-card">

            <div className="context-header">
              <div>
                <span className="context-label">LIVE</span>
                <h2>Latest Threat Context</h2>
              </div>

              <div className="context-shield">
                <ShieldAlert size={23} />
              </div>
            </div>

            {latestThreat ? (
              <div className="threat-details">

                <div className="threat-type">
                  <ShieldAlert size={18} />
                  <strong>{latestThreat.threat_type}</strong>
                </div>

                <div className="detail-row">
                  <span>Source IP</span>
                  <strong>{latestThreat.source_ip}</strong>
                </div>

                <div className="detail-row">
                  <span>Destination</span>
                  <strong>{latestThreat.destination_ip}</strong>
                </div>

                <div className="detail-row">
                  <span>Port</span>
                  <strong>{latestThreat.port}</strong>
                </div>

                <div className="detail-row">
                  <span>Protocol</span>
                  <strong>{latestThreat.protocol}</strong>
                </div>

                <div className="risk-box">
                  <div>
                    <span>RISK SCORE</span>
                    <strong>{latestThreat.risk_score}</strong>
                  </div>

                  <div className="risk-bar">
                    <div
                      style={{
                        width: `${Math.min(
                          latestThreat.risk_score || 0,
                          100
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="context-status">
                  <div>
                    <span>Severity</span>
                    <strong className="high">
                      {latestThreat.severity}
                    </strong>
                  </div>

                  <div>
                    <span>Action</span>
                    <strong className="blocked">
                      <Lock size={14} />
                      {latestThreat.action}
                    </strong>
                  </div>
                </div>

              </div>
            ) : (
              <div className="empty-context">
                <Activity size={30} />
                <p>
                  Ask the assistant a question to load the latest threat
                  context.
                </p>
              </div>
            )}

          </aside>

        </div>
      </div>

        {/* SENTINELAI_INVESTIGATION_TOOLS */}
        <section style={{
          margin: "20px 0",
          padding: 20,
          borderRadius: 14,
          background: "#111827",
          border: "1px solid #263449",
          color: "#E2E8F0"
        }}>
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12
          }}>
            <div>
              <h2 style={{ margin: 0, fontSize: 18 }}>
                Investigation Workspace
              </h2>
              <p style={{ color: "#94A3B8", fontSize: 13 }}>
                Run focused security investigations using the connected AI assistant.
              </p>
            </div>
            <span style={{ color: "#67E8F9", fontSize: 13 }}>
              {messages.length} conversation messages
            </span>
          </div>

          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit,minmax(190px,1fr))",
            gap: 10,
            marginTop: 16
          }}>
            {[
              {
                title: "Threat investigation",
                prompt: "Investigate the latest detected threats. Explain their severity, possible impact, and recommended response."
              },
              {
                title: "Network risk analysis",
                prompt: "Analyze the current network security risks and identify suspicious activity that needs investigation."
              },
              {
                title: "Zero Trust review",
                prompt: "Review the Zero Trust access decisions and explain how identity, device trust, and risk should influence access."
              },
              {
                title: "Incident response plan",
                prompt: "Prepare a prioritized incident response plan for the most important security threats."
              },
              {
                title: "Firewall policy review",
                prompt: "Review the firewall security posture and recommend improvements to reduce unnecessary network exposure."
              },
              {
                title: "Security summary",
                prompt: "Create a concise security operations summary covering recent threats, risks, and recommended actions."
              }
            ].map((item) => (
              <button
                key={item.title}
                type="button"
                disabled={loading}
                onClick={() => askAssistant(item.prompt)}
                style={{
                  textAlign: "left",
                  padding: 14,
                  borderRadius: 9,
                  border: "1px solid #334155",
                  background: "#172438",
                  color: "#E2E8F0",
                  cursor: loading ? "not-allowed" : "pointer",
                  opacity: loading ? 0.6 : 1
                }}
              >
                <strong>{item.title}</strong>
                <div style={{
                  color: "#94A3B8",
                  fontSize: 12,
                  marginTop: 6
                }}>
                  Start investigation →
                </div>
              </button>
            ))}
          </div>

          <div style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 10,
            marginTop: 18
          }}>
            <button
              type="button"
              disabled={messages.length === 0}
              onClick={() => {
                const report = messages.map((message, index) =>
                  `${index + 1}. ${message.role.toUpperCase()}:\n${message.text}`
                ).join("\n\n");

                const blob = new Blob(
                  [report],
                  { type: "text/plain;charset=utf-8" }
                );
                const url = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = url;
                link.download = "sentinelai-investigation-report.txt";
                link.click();
                URL.revokeObjectURL(url);
              }}
              style={{
                padding: "10px 14px",
                borderRadius: 8,
                border: 0,
                background: "#06B6D4",
                color: "#082F49",
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              Export conversation
            </button>

            <button
              type="button"
              disabled={messages.length === 0 || loading}
              onClick={() => {
                if (window.confirm("Clear the current conversation?")) {
                  setMessages([]);
                }
              }}
              style={{
                padding: "10px 14px",
                borderRadius: 8,
                border: "1px solid #7F1D1D",
                background: "#291820",
                color: "#FCA5A5",
                cursor: "pointer"
              }}
            >
              Clear conversation
            </button>
          </div>
        </section>
</PageLayout>
  );
}

export default Assistant;
